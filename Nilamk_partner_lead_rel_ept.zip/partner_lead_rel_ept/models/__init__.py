# -*- coding: utf-8 -*-

from . import salesperson_lead_count
from . import partner_lead_rel